export interface FollowerModel {
    readonly name: string;
    readonly avatar: string;
    readonly id: string
}

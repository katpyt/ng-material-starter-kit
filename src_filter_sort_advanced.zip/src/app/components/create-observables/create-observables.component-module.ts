import { NgModule } from '@angular/core';
import { CreateObservablesComponent } from './create-observables.component';

@NgModule({
  imports: [],
  declarations: [CreateObservablesComponent],
  providers: [],
  exports: [CreateObservablesComponent]
})


export class CreateObservalesComponentModule {

  
}

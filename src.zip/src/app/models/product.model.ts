export interface ProductModel {
  readonly title: string;
  readonly price: string;
}

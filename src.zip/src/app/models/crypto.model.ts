export interface CryptoModel {
  readonly symbol: string;
}

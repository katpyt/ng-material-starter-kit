import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ProductListComponent } from './components/product-list/product-list.component';
import { NamesListComponent } from './components/names-list/names-list.component';
import { CryptoListComponent } from './components/crypto-list/crypto-list.component';
import { CategoryListComponent } from './components/category-list/category-list.component';
import { CategoryMenuComponent } from './components/category-menu/category-menu.component';
import { CryptoRadioListComponent } from './components/crypto-radio-list/crypto-radio-list.component';
import { HolidayListComponent } from './components/holiday-list/holiday-list.component';
import { CategorySelectionListComponent } from './components/category-selection-list/category-selection-list.component';
import { NamesTableComponent } from './components/names-table/names-table.component';
import { ProductListComponentModule } from './components/product-list/product-list.component-module';
import { NamesListComponentModule } from './components/names-list/names-list.component-module';
import { CryptoListComponentModule } from './components/crypto-list/crypto-list.component-module';
import { CategoryListComponentModule } from './components/category-list/category-list.component-module';
import { CategoryMenuComponentModule } from './components/category-menu/category-menu.component-module';
import { CryptoRadioListComponentModule } from './components/crypto-radio-list/crypto-radio-list.component-module';
import { HolidayListComponentModule } from './components/holiday-list/holiday-list.component-module';
import { CategorySelectionListComponentModule } from './components/category-selection-list/category-selection-list.component-module';
import { NamesTableComponentModule } from './components/names-table/names-table.component-module';

@NgModule({
  imports: [RouterModule.forRoot([
    { path: 'products', component: ProductListComponent },
    { path: 'names-list', component: NamesListComponent },
    { path: 'crypto', component: CryptoListComponent },
    { path: 'checkbox-categories', component: CategoryListComponent },
    { path: 'categories-menu', component: CategoryMenuComponent },
    { path: 'crypto-radio-list', component: CryptoRadioListComponent },
    { path: 'public-holidays', component: HolidayListComponent },
    { path: 'categories', component: CategorySelectionListComponent },
    { path: 'list-1-single-table-names', component: NamesTableComponent }
  ]), ProductListComponentModule, NamesListComponentModule, CryptoListComponentModule, CategoryListComponentModule, CategoryMenuComponentModule, CryptoRadioListComponentModule, HolidayListComponentModule, CategorySelectionListComponentModule, NamesTableComponentModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }

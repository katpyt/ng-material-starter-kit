import { NgModule } from '@angular/core';
import { RoutePaginationFrontendCitiesComponent } from './route-pagination-frontend-cities.component';

@NgModule({
  imports: [],
  declarations: [RoutePaginationFrontendCitiesComponent],
  providers: [],
  exports: [RoutePaginationFrontendCitiesComponent]
})
export class RoutePaginationFrontendCitiesComponentModule {
}

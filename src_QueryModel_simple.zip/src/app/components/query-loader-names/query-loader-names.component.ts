import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, ViewEncapsulation } from '@angular/core';
import { catchError, map, Observable, of, startWith } from 'rxjs';
import { SlowDataService } from '../../services/slow-data.service';

interface ReuqestStateModel {
  isLoading: boolean;
  value?: string[];
  error?: HttpErrorResponse | Error
}

@Component({
  selector: 'app-query-loader-names',
  templateUrl: './query-loader-names.component.html',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class QueryLoaderNamesComponent {

  readonly namesList$: Observable<ReuqestStateModel> = this._slowDataService.getName().pipe(
    map((names) => {
      return {
        isLoading: false,
        value: names
      }
    }),
    startWith({
      isLoading: true
    }),
    catchError((error) => {
      return of({
        isLoading: false,
        error: error
      })
    })
  );



  constructor(private _slowDataService: SlowDataService) {
  }
}

import { NgModule } from '@angular/core';
import { QueryLoaderNamesComponent } from './query-loader-names.component';

@NgModule({
  imports: [],
  declarations: [QueryLoaderNamesComponent],
  providers: [],
  exports: [QueryLoaderNamesComponent]
})
export class QueryLoaderNamesComponentModule {
}

export interface SecurityFeatureModel {
  readonly id: string;
  readonly name: string;
}

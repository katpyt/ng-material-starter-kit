export interface DepartmentModel {
  readonly id: string;
  readonly name: string;
}

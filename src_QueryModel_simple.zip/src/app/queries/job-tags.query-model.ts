export interface JobTagsQueryModel {
  readonly jobName: string;
  readonly jobTags: string[];
}

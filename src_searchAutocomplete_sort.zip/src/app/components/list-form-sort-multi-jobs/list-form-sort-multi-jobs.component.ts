import { ChangeDetectionStrategy, Component, ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { combineLatest, map, Observable, of, startWith } from 'rxjs';
import { JobModel } from '../../models/job.model';
import { JobsService } from '../../services/jobs.service';

@Component({
  selector: 'app-list-form-sort-multi-jobs',
  styleUrls: ['./list-form-sort-multi-jobs.component.scss'],
  templateUrl: './list-form-sort-multi-jobs.component.html',
  encapsulation: ViewEncapsulation.Emulated,
  changeDetection: ChangeDetectionStrategy.OnPush
})


export class ListFormSortMultiJobsComponent {
  readonly orderPropertyDictionary: Observable<string[]> = of(['title', 'description'])
  readonly orderDirectionDictionary: Observable<string[]> = of(['asc', 'desc'])

  readonly orderProperty: FormControl = new FormControl();
  readonly orderDirectionProperty: FormControl = new FormControl();

  readonly jobsList$: Observable<JobModel[]> = combineLatest([
    this._jobsService.getAll(),
    this.orderProperty.valueChanges.pipe(startWith('')),
    this.orderDirectionProperty.valueChanges.pipe(startWith(''))
  ]).pipe(
    map(([list, sortProperty, sortDirection]) => {
      if (!sortProperty || !sortDirection) return list;

      return list.sort((a: Record<string, any>, b: Record<string, any>) => {
        return sortDirection === 'asc'
          ? a[sortProperty] > b[sortProperty] ? 1 : -1
          : a[sortProperty] > b[sortProperty] ? -1 : 1
      })
    })
  );

  constructor(private _jobsService: JobsService) {
  }
}

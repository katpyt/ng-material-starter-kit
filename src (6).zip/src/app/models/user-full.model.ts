export interface UserFullModel {
  readonly id: number;
  readonly email: string;
  readonly username: string;
  readonly password: string;
  readonly name: UserNameModel;
  readonly address: AddressModel;
  readonly phone: string;
}

export interface UserNameModel{
  readonly firstname: string;
  readonly lastname: string;
}

export interface AddressModel{
  readonly city: string;
  readonly street: string;
  readonly number: number;
  readonly zipcode: string;
  readonly geolocation: GeolocationModel;
}

export interface GeolocationModel{
  readonly lat: string;
  readonly long: string;
}


export interface UserAddRoleModel {
  readonly email: string;
  readonly roleId: number;
}

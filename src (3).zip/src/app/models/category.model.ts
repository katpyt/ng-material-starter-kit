export interface CategoryModel {
  readonly name: string;
}

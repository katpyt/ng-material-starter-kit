import { ChangeDetectionStrategy, Component, ViewEncapsulation } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserModel } from '../../models/user.model';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-roles',
  styleUrls: ['./user-roles.component.scss'],
  templateUrl: './user-roles.component.html',
  encapsulation: ViewEncapsulation.Emulated,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserRolesComponent {
  readonly userRoleControl = new FormControl('', [Validators.required]);
  readonly userRolesList$: Observable<UserModel[]> = this._userService.getUserRoles();

  constructor(private _userService: UserService) {
  }
}

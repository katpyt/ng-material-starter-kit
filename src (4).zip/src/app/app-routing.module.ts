import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ProductListComponent } from './components/product-list/product-list.component';
import { NamesListComponent } from './components/names-list/names-list.component';
import { CryptoListComponent } from './components/crypto-list/crypto-list.component';
import { CategoryListComponent } from './components/category-list/category-list.component';
import { CategoryMenuComponent } from './components/category-menu/category-menu.component';
import { CryptoRadioListComponent } from './components/crypto-radio-list/crypto-radio-list.component';
import { HolidayListComponent } from './components/holiday-list/holiday-list.component';
import { CategorySelectionListComponent } from './components/category-selection-list/category-selection-list.component';
import { NamesTableComponent } from './components/names-table/names-table.component';
import { ProductMultiListComponent } from './components/product-multi-list/product-multi-list.component';
import { ProductsTableComponent } from './components/products-table/products-table.component';
import { CryptoTableComponent } from './components/crypto-table/crypto-table.component';
import { JobPostTableComponent } from './components/job-post-table/job-post-table.component';
import { JobPostGridComponent } from './components/job-post-grid/job-post-grid.component';
import { InfluencerNestedListComponent } from './components/influencer-nested-list/influencer-nested-list.component';
import { InfluencerNestedTreeComponent } from './components/influencer-nested-tree/influencer-nested-tree.component';
import { FormComponent } from './components/form/form.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { FormControlNameComponent } from './components/form-control-name/form-control-name.component';
import { UserRolesComponent } from './components/user-roles/user-roles.component';
import { UniversityRadioListComponent } from './components/university-radio-list/university-radio-list.component';
import { ProductListComponentModule } from './components/product-list/product-list.component-module';
import { NamesListComponentModule } from './components/names-list/names-list.component-module';
import { CryptoListComponentModule } from './components/crypto-list/crypto-list.component-module';
import { CategoryListComponentModule } from './components/category-list/category-list.component-module';
import { CategoryMenuComponentModule } from './components/category-menu/category-menu.component-module';
import { CryptoRadioListComponentModule } from './components/crypto-radio-list/crypto-radio-list.component-module';
import { HolidayListComponentModule } from './components/holiday-list/holiday-list.component-module';
import { CategorySelectionListComponentModule } from './components/category-selection-list/category-selection-list.component-module';
import { NamesTableComponentModule } from './components/names-table/names-table.component-module';
import { ProductMultiListComponentModule } from './components/product-multi-list/product-multi-list.component-module';
import { ProductsTableComponentModule } from './components/products-table/products-table.component-module';
import { CryptoTableComponentModule } from './components/crypto-table/crypto-table.component-module';
import { JobPostTableComponentModule } from './components/job-post-table/job-post-table.component-module';
import { JobPostGridComponentModule } from './components/job-post-grid/job-post-grid.component-module';
import { InfluencerNestedListComponentModule } from './components/influencer-nested-list/influencer-nested-list.component-module';
import { InfluencerNestedTreeComponentModule } from './components/influencer-nested-tree/influencer-nested-tree.component-module';
import { FormComponentModule } from './components/form/form.component-module';
import { AddProductComponentModule } from './components/add-product/add-product.component-module';
import { FormControlNameComponentModule } from './components/form-control-name/form-control-name.component-module';
import { UserRolesComponentModule } from './components/user-roles/user-roles.component-module';
import { UniversityRadioListComponentModule } from './components/university-radio-list/university-radio-list.component-module';

@NgModule({
  imports: [RouterModule.forRoot([
    { path: 'products', component: ProductListComponent },
    { path: 'names-list', component: NamesListComponent },
    { path: 'crypto', component: CryptoListComponent },
    { path: 'checkbox-categories', component: CategoryListComponent },
    { path: 'categories-menu', component: CategoryMenuComponent },
    { path: 'crypto-radio-list', component: CryptoRadioListComponent },
    { path: 'public-holidays', component: HolidayListComponent },
    { path: 'categories', component: CategorySelectionListComponent },
    { path: 'list-1-single-table-names', component: NamesTableComponent },
    { path: 'list-1-multi-list-products', component: ProductMultiListComponent },
    { path: 'product-search', component: ProductsTableComponent },
    { path: 'crypto-table', component: CryptoTableComponent },
    { path: 'job-post-table', component: JobPostTableComponent },
    { path: 'list-1-multi-grid-list-jobs', component: JobPostGridComponent },
    { path: 'list-1-nested-list-and-chips-influencers', component: InfluencerNestedListComponent },
    { path: 'list-1-nested-tree-influencers', component: InfluencerNestedTreeComponent },
    { path: 'form', component: FormComponent },
    { path: 'add-product', component: AddProductComponent },
    { path: 'form-1-control-name', component: FormControlNameComponent },
    { path: 'user-roles', component: UserRolesComponent },
    { path: 'university-radio-list', component: UniversityRadioListComponent }
  ]), ProductListComponentModule, NamesListComponentModule, CryptoListComponentModule, CategoryListComponentModule, CategoryMenuComponentModule, CryptoRadioListComponentModule, HolidayListComponentModule, CategorySelectionListComponentModule, NamesTableComponentModule, ProductMultiListComponentModule, ProductsTableComponentModule, CryptoTableComponentModule, JobPostTableComponentModule, JobPostGridComponentModule, InfluencerNestedListComponentModule, InfluencerNestedTreeComponentModule, FormComponentModule, AddProductComponentModule, FormControlNameComponentModule, UserRolesComponentModule, UniversityRadioListComponentModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }

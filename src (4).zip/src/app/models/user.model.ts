export interface UserModel {
  readonly id: number;
  readonly role: string;
}

export interface JobTagsIdsModel {
  readonly id: number;
  readonly name: number;
}

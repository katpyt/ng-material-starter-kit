export interface NameModel {
    readonly name: string;
}

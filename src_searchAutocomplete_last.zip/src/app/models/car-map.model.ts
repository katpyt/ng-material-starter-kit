export interface CarModelMap {
    model: string;
    brandName: string;
    comfortFeatureName: string[];
    securityFeatureName: string[];
}

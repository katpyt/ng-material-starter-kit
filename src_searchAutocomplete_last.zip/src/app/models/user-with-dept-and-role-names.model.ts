export interface UserWithDeptAndRoleNamesModel {
  readonly id: number;
  readonly email: string;
  readonly departmentName: string;
  readonly roleName: string;
}

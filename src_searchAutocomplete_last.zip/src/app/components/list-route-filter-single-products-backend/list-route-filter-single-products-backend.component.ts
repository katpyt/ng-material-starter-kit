import { ChangeDetectionStrategy, Component, ViewEncapsulation } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { map, Observable, shareReplay, switchMap } from 'rxjs';
import { ProductModel } from '../../models/product.model';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-list-route-filter-single-products-backend',
  styleUrls: ['./list-route-filter-single-products-backend.component.scss'],
  templateUrl: './list-route-filter-single-products-backend.component.html',
  encapsulation: ViewEncapsulation.Emulated,
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ListRouteFilterSingleProductsBackendComponent {
  readonly categoriesList$: Observable<string[]> = this._productService.getAllCategories();
  public productsList$: Observable<ProductModel[]> = this._productService.getAllProducts();
  // readonly params$: Observable<Params> = this._activatedRoute.params.pipe(
  //   map((data) => ({ category: data['category'] }))
  // );
  readonly params$: Observable<Params> = this._activatedRoute.params.pipe(
    switchMap(data => this._productService.getAllInCategory(data['category'])),
  ).pipe(shareReplay(1));

  onFilteringChanged(category: string) {
    // const url = this._router.createUrlTree([], {
    //   relativeTo: this._activatedRoute.firstChild
    // }).toString();

    // console.log("url [" + url + "]");

    // this._location.go(url + '/products' + category);

    console.log(this._activatedRoute.routeConfig?.path?.split('/')[0]);

    this.productsList$ = this._productService.getAllInCategory(category);
    this._activatedRoute.params.pipe(
      switchMap(data => this._productService.getAllInCategory(data['category'])),
    ).subscribe(() => this._router.navigate([this._activatedRoute.routeConfig?.path?.split('/')[0] + '/products/', category]));
  }

  constructor(private _productService: ProductService, private _activatedRoute: ActivatedRoute, private _router: Router, private _location: Location) {
  }
}

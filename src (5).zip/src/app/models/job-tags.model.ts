export interface JobTagsModel {
   id: string;
   name: string;
  
}

export interface ProductModel {
  readonly title: string;
  readonly price: number;
  readonly image: string;
  readonly description: string;
  readonly category: string;
}

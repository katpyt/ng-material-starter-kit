import { ChangeDetectionStrategy, Component, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { CryptoModel } from '../../models/crypto.model';
import { CryptoService } from '../../services/crypto.service';

@Component({
  selector: 'app-subject-sorting-field-crypto',
  styleUrls: ['./subject-sorting-field-crypto.component.scss'],
  templateUrl: './subject-sorting-field-crypto.component.html',
  encapsulation: ViewEncapsulation.Emulated,
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class SubjectSortingFieldCryptoComponent {
  readonly cryptoList$: Observable<CryptoModel[]> = this._cryptoService.getAll();

  readonly orderValues$: Observable<string[]> = of(['asc', 'desc']);
  readonly sortValues$: Observable<string[]> = of(['lastPrice', 'openPrice', 'priceChange']);

  readonly orderForm = new FormControl('');

  constructor(private _cryptoService: CryptoService) {
  }

  onOrderFormSubmitted(orderForm: FormGroup): void {
  }
}

export interface UserWithAvatarModel {
  readonly name: string;
  readonly avatar: string;
  readonly id: string;
}

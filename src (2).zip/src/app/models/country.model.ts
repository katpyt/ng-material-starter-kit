export interface CountryModel {
  readonly name: string;
  readonly id: string;
}

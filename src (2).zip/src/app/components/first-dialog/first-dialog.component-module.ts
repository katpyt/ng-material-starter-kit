import { NgModule } from '@angular/core';
import { FirstDialogComponent } from './first-dialog.component';

@NgModule({
  imports: [],
  declarations: [FirstDialogComponent],
  providers: [],
  exports: [FirstDialogComponent]
})
export class FirstDialogComponentModule {
}

export interface JobTagsIdsModel {
  readonly id: string;
  readonly name: string;
}

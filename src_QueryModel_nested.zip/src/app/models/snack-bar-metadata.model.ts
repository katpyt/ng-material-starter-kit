export interface SnackBarMetadataModel {
  readonly stock: number;
  readonly delivery: number;
  readonly id: string;
  readonly productId: string;
}

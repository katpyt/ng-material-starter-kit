export interface UniversityModel {
  readonly webPages: string[];
  readonly stateProvince: string;
  readonly alphaTwoCode: string;
  readonly name: string;
  readonly country: string;
  readonly domains: string[];
}

export interface UserLoginModel {
  readonly username: string;
  readonly password: string;
}

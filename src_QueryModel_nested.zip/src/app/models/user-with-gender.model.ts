export interface UserWithGenderModel {
  readonly firstName: string;
  readonly lastName: string;
  readonly gender: string;
}

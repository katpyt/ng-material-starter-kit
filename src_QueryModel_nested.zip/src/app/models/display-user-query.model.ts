export interface DisplayUserQueryModel {
  readonly id: number;
  readonly email: string;
  readonly role: string;
}

export interface OrganizationModel {
  readonly id: string;
  readonly name: string;
}

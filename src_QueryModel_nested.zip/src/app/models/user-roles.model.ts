export interface UserRolesModel {
  readonly id: number;
  readonly role: string;
}

export interface JobTagsModel {
  readonly name: string;
  readonly title: string;
  readonly id: string;
  readonly description: string;
  readonly jobTagIds: number[]
}

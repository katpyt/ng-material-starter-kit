export interface JobModel {
  title: string;
  description: string;
  tags: string;
}

export interface HolidayModel {
  readonly name: string;
}

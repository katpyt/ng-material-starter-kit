export interface UserRoleDepartmentQueryModel {
  readonly userMail: string;
  readonly role: string;
  readonly department: string;
}

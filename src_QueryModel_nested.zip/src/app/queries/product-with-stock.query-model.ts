export interface ProductWithStockQueryModel {
  readonly productName: string;
  readonly productPrice: number;
  readonly stockValue: number;
}

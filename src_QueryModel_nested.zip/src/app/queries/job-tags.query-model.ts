export interface JobTagsQueryModel {
  readonly jobTitle: string;
  readonly jobTags: string[];
}

export interface CatFactModel {
  readonly fact: string;
  readonly length: number;
}

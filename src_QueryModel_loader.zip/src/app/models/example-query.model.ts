export interface ExampleQueryModel {
  readonly fullName: string;
}

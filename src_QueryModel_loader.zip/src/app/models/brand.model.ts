export interface BrandModel {
  readonly id: string;
  readonly name: string;
}

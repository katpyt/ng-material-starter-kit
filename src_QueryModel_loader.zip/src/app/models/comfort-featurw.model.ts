export interface ComfortFeatureModel {
  readonly id: string;
  readonly name: string;
}

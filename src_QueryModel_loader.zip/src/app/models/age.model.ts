export interface AgeModel {
  readonly age: number;
  readonly count: number;
  readonly name: string;
}

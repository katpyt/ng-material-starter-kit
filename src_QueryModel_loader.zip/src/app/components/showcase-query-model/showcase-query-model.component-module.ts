import { NgModule } from '@angular/core';
import { ShowcaseQueryModelComponent } from './showcase-query-model.component';

@NgModule({
  imports: [],
  declarations: [ShowcaseQueryModelComponent],
  providers: [],
  exports: [ShowcaseQueryModelComponent]
})
export class ShowcaseQueryModelComponentModule {
}
